import React from 'react';

// This component is no longer in use and has been replaced by AnimatedNailPolishIcon.tsx
export const WavingHandIcon: React.FC<{ className?: string }> = (props) => null;
